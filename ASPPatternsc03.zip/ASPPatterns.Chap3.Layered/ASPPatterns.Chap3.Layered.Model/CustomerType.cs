﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPPatterns.Chap3.Layered.Model
{
    public enum CustomerType
    {
        Standard = 0,
        Trade = 1
    }
}
