namespace ASPPatterns.Chap3.Layered.Repository
{
    partial class ShopDataContext
    {
    }
}
