﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPPatterns.Chap5.LiskovSubstitutionPrinciple
{
    public class RefundResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }
}
