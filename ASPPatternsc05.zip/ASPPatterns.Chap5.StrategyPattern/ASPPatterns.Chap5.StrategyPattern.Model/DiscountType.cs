﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPPatterns.Chap5.StrategyPattern.Model
{
    public enum DiscountType
    {
        NoDiscount = 0,
        MoneyOff = 1,
        PercentageOff = 2
    }
}
