﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPPatterns.Chap5.TemplateMethodPattern.Model
{
    public enum ReturnAction
    {
        FaultyReturn = 0,
        NoQuibblesReturn = 1
    }
}
